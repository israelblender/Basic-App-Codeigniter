# framework_codeigniter
Busca de Imagens em banco de dados para Slider utilizando FrameWork Codeigniter
