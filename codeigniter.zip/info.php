<?php
    phpInfo();
